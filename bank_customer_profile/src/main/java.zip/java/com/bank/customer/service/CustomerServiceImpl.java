package com.bank.customer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.customer.model.Customer;
import com.bank.customer.repository.CustomerRepository;

@Service
public class CustomerServiceImpl {

	
	@Autowired
	CustomerRepository customerRepository;
	
	
	
	public Customer saveCustomer(Customer customer) {
		customerRepository.save(customer);
		return customer;
	}
	
	public List<Customer> allCustomer(){
		List<Customer> customerList=customerRepository.findAll();
		return customerList;
		
	}

	public String deleteById(String id) {
		customerRepository.deleteById(id);
		return "customer deleted successFully";
	}

	public Customer updateCustomer(String id, Customer customer) {
       Optional<Customer> customerupdate=customerRepository.findById(id);
        Customer cust=customerupdate.get();
        cust.setEmail(customer.getEmail());
        cust.setFname(customer.getFname());
        cust.setLname(customer.getLname());
        cust.setMobile(customer.getMobile());
        customerRepository.save(cust);
        return cust;
	}

}
